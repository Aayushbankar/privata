[ ![Home](https://mosdac.gov.in/sites/default/files/mosdac_small.png) ](https://mosdac.gov.in/ "Home")
साइन अप  
SignUp  

New User Registration Form
*User Name : (#Min 5 Characters, No capital letters and First 3 must be Alphabet)
*Password (#Minimum 8 Characters, at least one number, one uppercase, one lowercase letter and one special character)
*Confirm Password
*Title Mr. Mrs. Ms. Dr. Prof.
*First Name
*Last Name
*Email :
Designation
*Organisation
*Address
*City
*Country India Afghanistan Albania Algeria Andorra Angola Antigua and Barbuda Argentina Armenia Australia Austria Azerbaijan Bahamas Bahrain Bangladesh Barbados Belarus Belgium Belize Benin Bhutan Bolivia Bosnia and Herzegovina Botswana Brazil Brunei Bulgaria Burkina Faso Burundi Cambodia Cameroon Canada Cape Verde Central African Republic Chad Chile China Colombia Comoros Congo (Brazzaville) Congo, Democratic Republic of the Costa Rica Côte d'Ivoire Croatia Cuba Cyprus Czech Republic Denmark Djibouti Dominica Dominican Republic East Timor (Timor Timur) Ecuador Egypt El Salvador Equatorial Guinea Eritrea Estonia Ethiopia Fiji Finland France Gabon Gambia, The Georgia Germany Ghana Greece Grenada Guatemala Guinea Guinea-Bissau Guyana Haiti Honduras Hungary Iceland Indonesia Iran Iraq Ireland Israel Italy Jamaica Japan Jordan Kazakhstan Kenya Kiribati Korea, North Korea, South Kuwait Kyrgyzstan Laos Latvia Lebanon Lesotho Liberia Libya Liechtenstein Lithuania Luxembourg Macedonia, Former Yugoslav Republic of Madagascar Malawi Malaysia Maldives Mali Malta Marshall Islands Mauritania Mauritius Mexico Micronesia, Federated States of Moldova Monaco Mongolia Morocco Mozambique Myanmar Namibia Nauru Nepal Netherlands New Zealand Nicaragua Niger Nigeria Norway Oman Pakistan Palau Panama Papua New Guinea Paraguay Peru Philippines Poland Portugal Qatar Romania Russia Rwanda Saint Kitts and Nevis Saint Lucia Saint Vincent and The Grenadines Samoa San Marino Sao Tome and Principe Saudi Arabia Senegal Serbia and Montenegro Seychelles Sierra Leone Singapore Slovakia Slovenia Solomon Islands Somalia South Africa Spain Sri Lanka Sudan Suriname Swaziland Sweden Switzerland Syria Taiwan Tajikistan Tanzania Thailand Togo Tonga Trinidad and Tobago Tunisia Turkey Turkmenistan Tuvalu Uganda Ukraine United Arab Emirates United Kingdom United States Uruguay Uzbekistan Vanuatu Vatican City Venezuela Vietnam Western Sahara Yemen Zambia Zimbabwe
*Mobile Number (#Mobile Number Format Should be like +91-XXXXXXXXXX)
Land Line (#Landlinenumber Format Should be like +91-XXXXXXXXXX)
*Purpose
![captcha](https://mosdac.gov.in/signup/) [ ![captcha-reload](https://mosdac.gov.in/signup/img/refresh-icon.png)](javascript:%20refreshCaptcha\(\);)
Captcha
x[I agree to the Terms and Conditions of the MOSDAC.**More![More Click Here](https://mosdac.gov.in/signup/external-link.png)**](https://mosdac.gov.in/terms-conditions)   
  

