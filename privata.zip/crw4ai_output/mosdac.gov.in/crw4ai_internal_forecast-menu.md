MOSDAC SSO
[Home (मुख पृष्ठ)](https://mosdac.gov.in)
English
  * [English](https://mosdac.gov.in/realms/Mosdac/login-actions/authenticate?client_id=mosdac&tab_id=yioPpghdUm0&client_data=eyJydSI6Imh0dHBzOi8vbW9zZGFjLmdvdi5pbi91b3BzL3JlZGlyZWN0X3VyaSIsInJ0IjoiY29kZSIsInN0IjoibTZ4aEUzN2Mzby1ZM01PcXo1dWdVQ05yd1lnIn0&execution=4cb21923-091b-4b14-8493-f5c02d7af1a3&kc_locale=en)
  * [Hindi (हिन्दी)](https://mosdac.gov.in/realms/Mosdac/login-actions/authenticate?client_id=mosdac&tab_id=yioPpghdUm0&client_data=eyJydSI6Imh0dHBzOi8vbW9zZGFjLmdvdi5pbi91b3BzL3JlZGlyZWN0X3VyaSIsInJ0IjoiY29kZSIsInN0IjoibTZ4aEUzN2Mzby1ZM01PcXo1dWdVQ05yd1lnIn0&execution=4cb21923-091b-4b14-8493-f5c02d7af1a3&kc_locale=hi)


#  MOSDAC Single-Sign-On(SSO) 
Username or email
Password
[Forgot Password?](https://mosdac.gov.in/realms/Mosdac/login-actions/reset-credentials?client_id=mosdac&tab_id=yioPpghdUm0&client_data=eyJydSI6Imh0dHBzOi8vbW9zZGFjLmdvdi5pbi91b3BzL3JlZGlyZWN0X3VyaSIsInJ0IjoiY29kZSIsInN0IjoibTZ4aEUzN2Mzby1ZM01PcXo1dWdVQ05yd1lnIn0)
  

मॉस्डैक, अंतरिक्ष उपयोग केंद्र, इसरो, भारत सरकार द्वारा निर्मित और संचालित
**Owned and maintained by MOSDAC, Space Applications Centre, Indian Space Research Organisation, Govt. of INDIA.**
