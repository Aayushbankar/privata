  
[Home (मुख पृष्ठ)](https://mosdac.gov.in)
मॉस्डैक सिंगल-साइन-ऑन (एसएसओ)    
MOSDAC Single-Sign-On (SSO)
आप लॉग आउट हो गए हैं   
You are logged out
मॉस्डैक, अंतरिक्ष उपयोग केंद्र, इसरो, भारत सरकार द्वारा निर्मित और संचालित
**Owned and maintained by MOSDAC, Space Applications Centre, Indian Space Research Organisation, Govt. of INDIA.**
