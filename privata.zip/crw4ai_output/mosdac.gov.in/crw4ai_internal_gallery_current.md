☰
Sat Aug 23 2025 05:30:00 (India Standard Time)
×
![](https://mosdac.gov.in/gallery/icons/mgallery.png)
Satellite/Forecast OCEAN SURFACE CURRENT
Sensor/Model Multi Satellite
Product Type 25 km
Product Indian Ocean Bay of Bengal Arabian Sea Pacific Ocean Atlantic Ocean Global Ocean
AutoLoad 15mins.
[ __ ](https://mosdac.gov.in/gallery/index.html?ds=current)
+ -
![](https://mosdac.gov.in/look/SCATCURRENT/gallery/2025/23AUG/E6CUR_23AUG2025_0000_NIO.gif)
23-08-2025_05:30 30-08-2025_05:30 23-08-2025_05:30
  *   *   *   *   *   *   *   * 

[ « ](https://mosdac.gov.in/gallery/index.html?ds=current) [ ▹ ](https://mosdac.gov.in/gallery/index.html?ds=current) [ ‖ ](https://mosdac.gov.in/gallery/index.html?ds=current) [ » ](https://mosdac.gov.in/gallery/index.html?ds=current)
10
Latest 8 Frames 16 Frames 24 Frames 32 Frames 48 Frames 60 Frames 120 Frames
[ « ](https://mosdac.gov.in/gallery/index.html?ds=current) [ » ](https://mosdac.gov.in/gallery/index.html?ds=current)
Loading... 
