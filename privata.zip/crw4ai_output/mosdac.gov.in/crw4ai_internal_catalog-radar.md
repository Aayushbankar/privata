A- A A+
[ ![Home](https://mosdac.gov.in/sites/default/files/mosdac_small.png) ](https://mosdac.gov.in/ "Home")
राडार उत्पाद सूची   
RADAR Catalog  

Satellite: RADAR   

Sensor: S BAND DWR CHERRAPUNJI S BAND DWR SHAR TERLS C BAND   
  

**X**
Show 10 25 50 100 entries
Search:
Sr.No | Product /  
Acq Calendar | Product Description | Processing Level | Temporal Resolution | Start Date | End Date | Processing Status | DOI  
---|---|---|---|---|---|---|---|---  
1 |  **RSCHR_L2B_STD**  
| DWR Data for Cheerapunji | L2B | 10 MINUTES | 2016-05-20 | 2022-11-05 | Active | [](https://dx.doi.org/)  
Showing 1 to 1 of 1 entries
Previous1Next
### Loading...
[Feedback](https://mosdac.gov.in/mosdac-feedback)
[About Us](https://mosdac.gov.in/about-us)
[Contact Us](https://mosdac.gov.in/contact-us)
[Copyright Policy](https://mosdac.gov.in/copyright-policy)
[Data Access Policy](https://mosdac.gov.in/data-access-policy)
[Hyperlink Policy](https://mosdac.gov.in/hyperlink-policy)
[Privacy Policy](https://mosdac.gov.in/privacy-policy)
[Website Policies](https://mosdac.gov.in/website-policies)
[Terms & Conditions](https://mosdac.gov.in/terms-conditions)
[FAQs](https://mosdac.gov.in/faq-page)
[![ISRO](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/logo-transparent.png?itok=IUS20l-w)](http://www.isro.gov.in) [![Space Applications Center](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/saclogo.png?itok=_Jv4AuIn)](http://www.sac.gov.in) [![NationalPortal](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/india-gov_0.png?itok=yssAPH3m)](http://www.india.gov.in) [![MyGov](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/mygov_0.png?itok=Po-dzdT3)](http://mygov.in/) >[![DigitalIndia](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/digital-india_0.png?itok=ntlP7atE)](http://www.digitalindia.gov.in/) [![DataPortal](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/data-gov.png?itok=qYA78FgB)](http://data.gov.in)
Ver 3.0; Last reviewed and updated on 22 Aug, 2024 
