A- A A+
[ ![Home](https://mosdac.gov.in/sites/default/files/mosdac_small.png) ](https://mosdac.gov.in/ "Home")
यथास्थिति (AWS) उत्पाद सूची   
Insitu (AWS) Catalog  

Satellite: In-situ   

Sensor: AMS AWS AWSAGRI AWSUPG IMDAWS   
  

**X**
Show 10 25 50 100 entries
Search:
Sr.No | Station Name | State | Station ID | Station Key | Latitude | Longitude | Start Date | End Date | Processing Status | Temporal Resolution  
---|---|---|---|---|---|---|---|---|---|---  
1 |  **Diglipur,Portblair**  
| ANDAMAN & NICOBAR | 15F488 | AGROMET18 | 13.26 | 93.01 | 2011-02-15 | 2016-03-30 | In-Active | Half Hourly  
2 |  **CRIDA Farm,Hayathnagar, Hyderabad**  
| ANDHRA PRADESH | 15F0FF | AGROMET02 | 17.34 | 78.59 | 2010-12-31 | 2017-12-06 | In-Active | Half Hourly  
3 |  **SDSC, SHAR, Sriharikota**  
| ANDHRA PRADESH | 15F464 | AGROMET06 | 13.62 | 80.23 | 2010-12-31 | 2016-02-14 | In-Active | Half Hourly  
4 |  **Rajendra Agricultural University, PUSA, Samastipur**  
| BIHAR | 15F47F | AGROMET15 | 25.98 | 85.67 | 2010-12-31 | 2017-06-29 | In-Active | Half Hourly  
5 |  **Rice Research Station, Anand Agricultural University, Nawagam.**  
| GUJARAT | 15F102 | AGROMET03 | 22.80 | 72.57 | 2010-12-31 | 2017-09-19 | In-Active | Half Hourly  
6 |  **Junagadh Agricultural University, Junagadh**  
| GUJARAT | 15F105 | AGROMET04 | 21.50 | 70.44 | 2011-04-05 | 2017-08-17 | In-Active | Half Hourly  
7 |  **Range Office Research Centre, Dhorado, Kutch**  
| GUJARAT | 15F485 | AGROMET17 | 23.80 | 69.50 | 2010-12-31 | 2016-09-16 | In-Active | Half Hourly  
8 |  **Regional Agricultural Research Station, Bijapur.**  
| KARNATAKA | 15F0FC | AGROMET01 | 16.78 | 75.75 | 2011-07-30 | 2016-09-26 | In-Active | Half Hourly  
9 |  **IISC Bengaluru. (Gopal Pura)**  
| KARNATAKA | 15F518 | AGROMET24 | 11.76 | 76.59 | 2012-01-31 | 2016-04-30 | In-Active | Half Hourly  
10 |  **Zonal Agricultural Research Station, Powerkhed, Hoshangabad**  
| MADHYA PRADESH | 15F46A | AGROMET08 | 22.70 | 77.74 | 2010-12-31 | 2017-08-06 | In-Active | Half Hourly  
Showing 1 to 10 of 24 entries
Previous123Next
### Loading...
[Feedback](https://mosdac.gov.in/mosdac-feedback)
[About Us](https://mosdac.gov.in/about-us)
[Contact Us](https://mosdac.gov.in/contact-us)
[Copyright Policy](https://mosdac.gov.in/copyright-policy)
[Data Access Policy](https://mosdac.gov.in/data-access-policy)
[Hyperlink Policy](https://mosdac.gov.in/hyperlink-policy)
[Privacy Policy](https://mosdac.gov.in/privacy-policy)
[Website Policies](https://mosdac.gov.in/website-policies)
[Terms & Conditions](https://mosdac.gov.in/terms-conditions)
[FAQs](https://mosdac.gov.in/faq-page)
[![ISRO](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/logo-transparent.png?itok=IUS20l-w)](http://www.isro.gov.in) [![Space Applications Center](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/saclogo.png?itok=_Jv4AuIn)](http://www.sac.gov.in) [![NationalPortal](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/india-gov_0.png?itok=yssAPH3m)](http://www.india.gov.in) [![MyGov](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/mygov_0.png?itok=Po-dzdT3)](http://mygov.in/) >[![DigitalIndia](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/digital-india_0.png?itok=ntlP7atE)](http://www.digitalindia.gov.in/) [![DataPortal](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/data-gov.png?itok=qYA78FgB)](http://data.gov.in)
Ver 3.0; Last reviewed and updated on 22 Aug, 2024 
