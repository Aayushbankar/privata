☰
Wed Sep 10 2025 12:49:00 (India Standard Time)
×
![](https://mosdac.gov.in/gallery/icons/mgallery.png)
Satellite/Forecast DWR
Sensor/Model TERLS SHAR CHERRAPUNJI
Product Type C-BAND
Product Maximum Reflectivity Plan Position Indicator(Z) Plan Position Indicator(S) Plan Position Indicator(V) Surface Rainfall Intensity Wind Vectors
AutoLoad 15mins.
[ __ ](https://mosdac.gov.in/gallery/index.html?ds=dwr)
+ -
![](https://mosdac.gov.in/look/DWR/RCTLS/2025/10SEP/RCTLS_10SEP2025_071944_L2B_STD_MAXZ.gif)
10-09-2025_12:49 10-09-2025_15:51 10-09-2025_12:49
  *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   * 

[ « ](https://mosdac.gov.in/gallery/index.html?ds=dwr) [ ▹ ](https://mosdac.gov.in/gallery/index.html?ds=dwr) [ ‖ ](https://mosdac.gov.in/gallery/index.html?ds=dwr) [ » ](https://mosdac.gov.in/gallery/index.html?ds=dwr)
10
Latest 8 Frames 16 Frames 24 Frames 32 Frames 48 Frames 60 Frames 120 Frames
[ « ](https://mosdac.gov.in/gallery/index.html?ds=dwr) [ » ](https://mosdac.gov.in/gallery/index.html?ds=dwr)
Loading... 
