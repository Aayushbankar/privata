[Skip to main Content](https://mosdac.gov.in/terms-conditions#main-content "Skip to main Content")
[-A](javascript:;) [A](javascript:;) [+A](javascript:;)
[A](javascript:drupalHighContrast.enableStyles\(\))[A](javascript:drupalHighContrast.disableStyles\(\))
हिन्दी English
## Secondary menu
  * [SignUp](https://mosdac.gov.in/internal/registration)
  * [Login](https://mosdac.gov.in/internal/uops)
  * [Logout](https://mosdac.gov.in/internal/logout)

[ ![Home](https://mosdac.gov.in/sites/default/files/mosdac_small.png) ](https://mosdac.gov.in/ "Home")
**[ Meteorological & Oceanographic Satellite Data Archival Centre](https://mosdac.gov.in/ "Home") **
Space Applications Centre, ISRO 
  * [Home](https://mosdac.gov.in/)
  * [Missions »](https://mosdac.gov.in/terms-conditions)
    * [INSAT-3DR](https://mosdac.gov.in/insat-3dr)
    * [INSAT-3D](https://mosdac.gov.in/insat-3d)
    * [KALPANA-1](https://mosdac.gov.in/kalpana-1)
    * [INSAT-3A](https://mosdac.gov.in/insat-3a)
    * [MeghaTropiques](https://mosdac.gov.in/megha-tropiques)
    * [SARAL-AltiKa](https://mosdac.gov.in/saral-altika)
    * [OCEANSAT-2](https://mosdac.gov.in/oceansat-2)
    * [OCEANSAT-3](https://mosdac.gov.in/oceansat-3)
    * [INSAT-3DS](https://mosdac.gov.in/insat-3ds)
    * [SCATSAT-1](https://mosdac.gov.in/scatsat-1)
  * [Catalog »](https://mosdac.gov.in/terms-conditions)
    * [Satellite](https://mosdac.gov.in/internal/catalog-satellite)
    * [Insitu (AWS)](https://mosdac.gov.in/internal/catalog-insitu)
    * [RADAR](https://mosdac.gov.in/internal/catalog-radar)
  * [Galleries »](https://mosdac.gov.in/terms-conditions)
    * [Satellite Products](https://mosdac.gov.in/internal/gallery)
    * [Weather Forecast](https://mosdac.gov.in/internal/gallery/weather)
    * [Ocean Forecast](https://mosdac.gov.in/internal/gallery/ocean)
    * [RADAR (DWR)](https://mosdac.gov.in/internal/gallery/dwr)
    * [Global Ocean Current](https://mosdac.gov.in/internal/gallery/current)
  * [Data Access »](https://mosdac.gov.in/terms-conditions)
    * [Order Data](https://mosdac.gov.in/internal/uops)
    * [API based Access](https://mosdac.gov.in/user-manual-mosdac-data-download-api)
    * [Open Data »](https://mosdac.gov.in/terms-conditions)
      * [Atmosphere »](https://mosdac.gov.in/terms-conditions)
        * [Bayesian based MT-SAPHIR rainfall](https://mosdac.gov.in/bayesian-based-mt-saphir-rainfall)
        * [GPS derived Integrated water vapour](https://mosdac.gov.in/gps-derived-integrated-water-vapour)
        * [GSMap ISRO Rain](https://mosdac.gov.in/gsmap-isro-rain)
        * [METEOSAT8 Cloud Properties](https://mosdac.gov.in/meteosat8-cloud-properties)
      * [Land »](https://mosdac.gov.in/terms-conditions)
        * [3D Volumetric TERLS DWRproduct](https://mosdac.gov.in/3d-volumetric-terls-dwrproduct)
        * [Inland Water Height](https://mosdac.gov.in/inland-water-height)
        * [River Discharge](https://mosdac.gov.in/river-discharge)
        * [Soil Moisture](https://mosdac.gov.in/soil-moisture-0)
      * [Ocean »](https://mosdac.gov.in/terms-conditions)
        * [Global Ocean Surface Current](https://mosdac.gov.in/global-ocean-surface-current)
        * [High Resolution Sea Surface Salinity](https://mosdac.gov.in/high-resolution-sea-surface-salinity)
        * [Indian Mainland Coastal Product](https://mosdac.gov.in/indian-mainland-coastal-product)
        * [Ocean Subsurface](https://mosdac.gov.in/ocean-subsurface)
        * [Oceanic Eddies Detection](https://mosdac.gov.in/oceanic-eddies-detection)
        * [Sea Ice Occurrence Probability](https://mosdac.gov.in/sea-ice-occurrence-probability)
        * [Wave based Renewable Energy](https://mosdac.gov.in/wave-based-renewable-energy)
    * [Cal-Val](https://mosdac.gov.in/internal/calval-data)
    * [Forecast](https://mosdac.gov.in/internal/forecast-menu)
    * [RSS Feeds](https://mosdac.gov.in/rss-feed "ISROCast")
  * [Reports »](https://mosdac.gov.in/terms-conditions)
    * [Calibration »](https://mosdac.gov.in/terms-conditions)
      * [Insitu](https://mosdac.gov.in/insitu)
      * [Relative](https://mosdac.gov.in/calibration-reports)
    * [Validation](https://mosdac.gov.in/validation-reports)
    * [Data Quality](https://mosdac.gov.in/data-quality)
    * [Weather](https://mosdac.gov.in/weather-reports)
  * [Atlases](https://mosdac.gov.in/atlases)
  * [Tools](https://mosdac.gov.in/tools)
  * [Sitemap](https://mosdac.gov.in/sitemap)
  * [Help](https://mosdac.gov.in/help)


## You are here
[Home](https://mosdac.gov.in/) » Terms & Conditions
# Terms & Conditions
This website is designed, developed and maintained by Space Applications Centre, Indian Space Research Organisation, Department of Space, Government of India.
Though all efforts have been made to ensure the accuracy and currency of the content of this website, the same should not be construed as a statement of law or used for any legal purposes.
Under no circumstances the MOSDAC will be liable for any expense, loss or damage including, without limitation, indirect or consequential loss or damage, or any expense, loss or damage whatsoever arising from use, or loss or use, of data, arising out of or in connection with use of this website.
The terms and conditions shall be governed by and construed in accordance with the Indian Laws. Any dispute arising under these terms and conditions shall be subject to the exclusive jurisdiction of the courts of India.
This Website provides links to other web pages that are not part of MOSDAC domain, and MOSDAC does not exercise any control over the information on these external links. External links are provided for your convenience and for reasons consistent with objectives of MOSDAC. Once you link to another site, you are subjected to the Terms & Conditions and privacy policy of that new site. MOSDAC does not guarantee the availability of such linked pages at all times. MOSDAC cannot authorize the use of copyright materials contained in the linked websites. Users are advised to request such authorization from the owner of the linked website. MOSDAC does not guarantee that linked websites comply with Indian Government Web Guidelines.
  * [![हिन्दी](https://mosdac.gov.in/sites/all/modules/languageicons/flags/hi.png) हिन्दी](https://mosdac.gov.in/node/1271?language=hi "निबंधन एवं शर्तें")


## Search
Search 
## Follow Us
  * [![Facebook icon](https://mosdac.gov.in/sites/all/modules/social_media_links/libraries/elegantthemes/PNG/facebook.png)](https://www.facebook.com/mosdac.sac.isro "Facebook")
  * [![Youtube \(Channel\) icon](https://mosdac.gov.in/sites/all/modules/social_media_links/libraries/elegantthemes/PNG/youtube.png)](http://www.youtube.com/channel/UCDVkai9WIgY2ZgrlF_08Yeg "Youtube \(Channel\)")
  * [![RSS icon](https://mosdac.gov.in/sites/all/modules/social_media_links/libraries/elegantthemes/PNG/rss.png)](https://mosdac.gov.in/rss.xml "RSS")


Website owned and maintained by MOSDAC, Space Applications Centre, Indian Space Research Organisation, Govt. of INDIA.
  * [![CQW LOGO](https://mosdac.gov.in/docs/cqw_logo.gif)](https://mosdac.gov.in/docs/STQC.pdf "Quality Certificate")


  * [Feedback](https://mosdac.gov.in/mosdac-feedback)
  * [About Us](https://mosdac.gov.in/about-us)
  * [Contact Us](https://mosdac.gov.in/contact-us)
  * [Copyright Policy](https://mosdac.gov.in/copyright-policy)
  * [Data Access Policy](https://mosdac.gov.in/data-access-policy)
  * [Hyperlink Policy](https://mosdac.gov.in/hyperlink-policy)
  * [Privacy Policy](https://mosdac.gov.in/privacy-policy)
  * [Website Policies](https://mosdac.gov.in/website-policies)
  * [Terms & Conditions](https://mosdac.gov.in/terms-conditions)
  * [FAQs](https://mosdac.gov.in/faq-page)


  * [![ISRO](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/logo-transparent.png?itok=IUS20l-w)](http://www.isro.gov.in)
  * [![Space Applications Center](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/saclogo.png?itok=_Jv4AuIn)](http://www.sac.gov.in)
  * [![NationalPortal](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/india-gov_0.png?itok=yssAPH3m)](http://www.india.gov.in)
  * [![MyGov](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/mygov_0.png?itok=Po-dzdT3)](http://mygov.in/)
  * [![DigitalIndia](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/digital-india_0.png?itok=ntlP7atE)](http://www.digitalindia.gov.in/)
  * [![DataPortal](https://mosdac.gov.in/sites/default/files/styles/thumbnail/public/data-gov.png?itok=qYA78FgB)](http://data.gov.in)


"Ver 3.0; Last reviewed and updated on 10 Sep, 2025& Served By: Web-Srv-Pri
[](https://mosdac.gov.in/terms-conditions "Previous")[](https://mosdac.gov.in/terms-conditions "Next")
[](https://mosdac.gov.in/terms-conditions)
[](https://mosdac.gov.in/terms-conditions "Previous")[](https://mosdac.gov.in/terms-conditions "Next")
[](https://mosdac.gov.in/terms-conditions "Close")[](https://mosdac.gov.in/terms-conditions)[](https://mosdac.gov.in/terms-conditions)[](https://mosdac.gov.in/terms-conditions "Pause Slideshow")[](https://mosdac.gov.in/terms-conditions "Play Slideshow")
[Back to top](https://mosdac.gov.in/terms-conditions#top)
