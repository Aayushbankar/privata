☰
Tue Sep 09 2025 11:30:00 (India Standard Time)
×
![](https://mosdac.gov.in/gallery/icons/mgallery.png)
Satellite/Forecast OCEAN FORECAST
Sensor/Model REGIONAL GLOBAL
Product Type Model Forecast
Product Sea Surface Current Speed Mixed Layer Depth Sea Level Anomaly Sea Surface Salinity Sea Surface Temperature TCHP Anomaly Mean Wave Period Swell Height Significant Wave Height
AutoLoad 15mins.
[ __ ](https://mosdac.gov.in/gallery/index.html?ds=ocean)
+ -
![](https://mosdac.gov.in/look/AOSF/REGNL/gallery/2025/09SEP/REGNL_09SEP2025_0600Z_CUR.gif)
09-09-2025_11:30 14-09-2025_05:30 09-09-2025_11:30
  *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   * 

[ « ](https://mosdac.gov.in/gallery/index.html?ds=ocean) [ ▹ ](https://mosdac.gov.in/gallery/index.html?ds=ocean) [ ‖ ](https://mosdac.gov.in/gallery/index.html?ds=ocean) [ » ](https://mosdac.gov.in/gallery/index.html?ds=ocean)
10
Latest 8 Frames 16 Frames 24 Frames 32 Frames 48 Frames 60 Frames 120 Frames
[ « ](https://mosdac.gov.in/gallery/index.html?ds=ocean) [ » ](https://mosdac.gov.in/gallery/index.html?ds=ocean)
Loading... 
