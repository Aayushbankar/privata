☰
Wed Sep 10 2025 05:30:00 (India Standard Time)
×
![](https://mosdac.gov.in/gallery/icons/mgallery.png)
Satellite/Forecast WEATHER FORECAST CONTRAIL FORECAST
Sensor/Model WRF
Product Type 5 km
Product Temperature Relative Humidity Cloud Wind(Surface) Wind(850 hpa) Wind(700 hpa) Wind(500 hpa) Wind(200 hpa) Rain(24 hourly) Rain(3 hourly) Discomfort Index Wind Chill Temperature Ahmedabad Temperature
AutoLoad 15mins.
[ __ ](https://mosdac.gov.in/gallery/index.html?ds=weather)
+ -
![](https://mosdac.gov.in/look/WRF/gallery/2025/10SEP/WRF5K_10SEP2025_0000_TEMP.tif)
10-09-2025_05:30 13-09-2025_05:30 10-09-2025_05:30
  *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   * 

[ « ](https://mosdac.gov.in/gallery/index.html?ds=weather) [ ▹ ](https://mosdac.gov.in/gallery/index.html?ds=weather) [ ‖ ](https://mosdac.gov.in/gallery/index.html?ds=weather) [ » ](https://mosdac.gov.in/gallery/index.html?ds=weather)
10
Latest 8 Frames 16 Frames 24 Frames 32 Frames 48 Frames 60 Frames 120 Frames
[ « ](https://mosdac.gov.in/gallery/index.html?ds=weather) [ » ](https://mosdac.gov.in/gallery/index.html?ds=weather)
Loading... 
